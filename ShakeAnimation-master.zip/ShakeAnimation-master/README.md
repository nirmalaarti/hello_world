# ShakeAnimation
This is a simple application in Android that performs a shake of a View element. 

If you are interested in creating a shake effect in Android, check out this example.

The relevant code is in the MainActivity where you actually perform the animation, and the animation resource file, found in res/anim/shake.xml.

Feel free to use this code, criticize it or just contact me at teoinke@gmail.com.

